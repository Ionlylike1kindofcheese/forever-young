keuzetafel = int(input("Welke tafel wilt u laten uitrekenen? "))
for i in range(1,11):
    print(i * keuzetafel)
