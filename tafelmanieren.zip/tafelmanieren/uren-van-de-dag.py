text1 = "AM"
for x in range(2):
    if x == 1:
        text1 = "PM"
    for i in range(1,13):
        print(i, text1)
